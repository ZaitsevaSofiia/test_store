package com.example.ProjectTest_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class  ProjectTest3Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectTest3Application.class, args);
	}

}
